/**
 * Type definitions for the Cloudflare Access authentication library.
 *
 * @module
 */

// ---------------------------------------------------------------------------
// Logger
// ---------------------------------------------------------------------------

/**
 * Minimal structured logger accepted by the authentication middleware.
 *
 * This interface is intentionally defined here (rather than imported
 * from `cloudflare-logging`) so that the auth library remains
 * standalone.  The `cloudflare-logging` package independently defines
 * a structurally identical interface and can therefore satisfy this
 * type without an explicit dependency.
 *
 * When no logger is provided the middleware falls back to a simple
 * `console.*`-based default.
 */
export interface Logger {
  debug(message: string, data?: Record<string, unknown>): void;
  info(message: string, data?: Record<string, unknown>): void;
  warn(message: string, data?: Record<string, unknown>): void;
  error(message: string, data?: Record<string, unknown>): void;
}

// ---------------------------------------------------------------------------
// Hono context variables
// ---------------------------------------------------------------------------

/**
 * Variables set on the Hono context by the {@link cloudflareAccess} middleware.
 *
 * Wire this into your Hono generic so handlers can call
 * `c.get("userEmail")` and `c.get("userSub")`.
 *
 * @example
 * ```ts
 * const app = new Hono<{ Bindings: Env; Variables: AuthVariables }>();
 * ```
 */
export type AuthVariables = {
  /** Authenticated user's email address (from the JWT `email` claim). */
  userEmail: string;
  /** Authenticated user's unique identifier (from the JWT `sub` claim). */
  userSub: string;
};

// ---------------------------------------------------------------------------
// Path policy
// ---------------------------------------------------------------------------

/**
 * A single path-matching rule used by both middleware functions to
 * decide whether a request requires authentication.
 *
 * Policies are evaluated in order; the **first match wins**.
 */
export interface PathPolicy {
  /** Regular expression tested against the request pathname. */
  pattern: RegExp;
  /**
   * `true`  - the matching path requires authentication.
   * `false` - the matching path is public / anonymous.
   */
  authenticate: boolean;
  /**
   * Controls the response when an unauthenticated request hits this
   * path in {@link developerAuthentication}:
   *
   * - `true` *(default)* — 302 redirect to the login form.  Appropriate
   *   for page routes where the browser should navigate to a login UI.
   * - `false` — 401 JSON `{ error: "Authentication required" }`.
   *   Appropriate for API routes, matching what {@link cloudflareAccess}
   *   does in production.
   *
   * {@link cloudflareAccess} always returns 401 regardless of this
   * setting.
   *
   * Only meaningful when `authenticate` is `true`.
   */
  redirect?: boolean;
}

/**
 * Result of evaluating a request pathname against a {@link PathPolicy}
 * array via {@link matchPolicy}.
 */
export interface PolicyMatch {
  /** Whether the matching policy requires authentication. */
  authenticate: boolean;
  /**
   * Whether the middleware should redirect (`true`) or return 401
   * (`false`) for unauthenticated requests.  Defaults to `true` when
   * the original {@link PathPolicy} did not specify a value.
   */
  redirect: boolean;
}

// ---------------------------------------------------------------------------
// Developer authentication settings
// ---------------------------------------------------------------------------

/**
 * Configuration for {@link developerAuthentication}.
 *
 * Every property is optional; sensible defaults are provided.
 */
export interface DeveloperAuthSettings {
  /**
   * Path policies evaluated in order (first match wins).
   *
   * When omitted **all** paths require authentication.
   *
   * @example
   * ```ts
   * policies: [
   *   { pattern: /^\/api\/version$/, authenticate: false },
   *   { pattern: /^\/api\//, authenticate: true },
   * ]
   * ```
   */
  policies?: PathPolicy[];

  /** Pathname for the login form (default `"/_auth/login"`). */
  loginPath?: string;

  /** Pathname for the login callback (default `"/_auth/callback"`). */
  callbackPath?: string;

  /**
   * HMAC secret used to sign developer JWTs.
   *
   * Defaults to a well-known key that is **only** safe for local
   * development.  Override this if you need a stable secret across
   * restarts.
   */
  devSecret?: string;

  /** JWT lifetime in seconds (default `86400` / 24 h). */
  tokenLifetime?: number;

  /**
   * Optional structured logger.
   *
   * When omitted the middleware logs via `console.*` with a
   * `[dev-auth]` prefix.  Pass a logger created by
   * `cloudflare-logging` (or any object satisfying the
   * {@link Logger} interface) to gain level filtering and
   * formatted output.
   */
  logger?: Logger;
}

// ---------------------------------------------------------------------------
// Cloudflare Access settings
// ---------------------------------------------------------------------------

/**
 * Configuration for {@link cloudflareAccess}.
 *
 * Every property is optional; sensible defaults are provided.
 */
export interface CloudflareAccessSettings {
  /**
   * Path policies evaluated in order (first match wins).
   *
   * Typically the **same array** passed to
   * {@link developerAuthentication} so that both middleware agree on
   * which paths are public vs. protected.
   *
   * - `authenticate: false` → bypass JWT validation entirely.
   * - `authenticate: true`  → require a valid JWT (401 if missing).
   * - No matching policy     → behaviour is controlled by
   *   {@link defaultAction}.
   */
  policies?: PathPolicy[];

  /**
   * What to do when the request path does **not** match any policy.
   *
   * - `"block"` (default) — return 401 if no valid JWT is present.
   * - `"bypass"` — allow the request through without authentication.
   *   If a valid JWT *is* present it will still be verified and the
   *   context variables will be set; if not, the request continues
   *   with no user information.
   */
  defaultAction?: "block" | "bypass";

  /**
   * Cloudflare Access team domain used to fetch the public JWKS.
   *
   * When omitted the middleware reads `c.env.CLOUDFLARE_TEAM_DOMAIN` at
   * request time.
   */
  teamDomain?: string;

  /**
   * Application Audience Tag.  When provided the middleware verifies the
   * JWT `aud` claim contains this value.  When omitted audience
   * validation is skipped.
   */
  audience?: string;

  /**
   * Enable HS256 developer-token verification.
   *
   * **Default `false` (fail-closed).**  When `false`, {@link cloudflareAccess}
   * verifies the JWT **only** against the Cloudflare Access JWKS — a
   * developer-signed HS256 token (including one signed with the public
   * {@link DEFAULT_DEV_SECRET}) is rejected.  This prevents a deployed
   * Worker from silently trusting forgeable dev tokens.
   *
   * Enable it **only** in local development, gated on a build-time signal
   * that is statically `false` in production:
   *
   * ```ts
   * app.use(cloudflareAccess({ policies, enableDevTokens: import.meta.env.DEV }));
   * ```
   *
   * When enabled without an explicit {@link devSecret}, the middleware logs
   * a one-time warning that it is verifying with the public default secret.
   */
  enableDevTokens?: boolean;

  /**
   * HMAC secret for validating developer-generated JWTs.
   *
   * **Ignored unless {@link enableDevTokens} is `true`.**  Must match the
   * `devSecret` used by {@link developerAuthentication} (or the Vite
   * plugin).  When dev tokens are enabled and this is omitted, the
   * well-known {@link DEFAULT_DEV_SECRET} is used and a one-time warning is
   * logged — never rely on that for production security.
   */
  devSecret?: string;

  /**
   * Optional structured logger.
   *
   * When omitted the middleware logs via `console.*` with a
   * `[cf-access]` prefix.  Pass a logger created by
   * `cloudflare-logging` (or any object satisfying the
   * {@link Logger} interface) to gain level filtering and
   * formatted output.
   */
  logger?: Logger;
}

// ---------------------------------------------------------------------------
// Internal JWT payload shape
// ---------------------------------------------------------------------------

/**
 * Subset of the Cloudflare Access JWT payload that the library cares about.
 *
 * @internal
 */
export interface AccessJwtPayload {
  /** User email. */
  email: string;
  /** Subject (unique user identifier). */
  sub: string;
  /** Issuer URL. */
  iss: string;
  /** Audience (application audience tag). */
  aud?: string | string[];
  /** Issued-at timestamp. */
  iat: number;
  /** Expiry timestamp. */
  exp: number;
  /**
   * Token type.  Cloudflare Access sets this to `"app"`.  The developer
   * middleware sets it to `"dev"` so that {@link cloudflareAccess} can
   * choose the correct verification strategy.
   */
  type?: string;
}
